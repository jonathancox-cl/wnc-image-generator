from flask import Flask, request, send_file
from PIL import Image, ImageDraw, ImageFont
import io
import os
import urllib.request

app = Flask(__name__)

FONT_DIR = os.path.join(os.path.dirname(__file__), 'fonts')
os.makedirs(FONT_DIR, exist_ok=True)

FONT_URLS = {
    'DejaVuSans-Bold.ttf': 'https://github.com/dejavu-fonts/dejavu-fonts/raw/master/ttf/DejaVuSans-Bold.ttf',
    'DejaVuSans.ttf': 'https://github.com/dejavu-fonts/dejavu-fonts/raw/master/ttf/DejaVuSans.ttf',
    'Caladea-Bold.ttf': 'https://fonts.gstatic.com/s/caladea/v7/i7dPIFZ9Zz-WBtRtedDbYE98RXi4EwSsbg.woff2',
}

def ensure_fonts():
    # Use system fonts if available, otherwise fall back to PIL default
    pass

def get_font(style, size):
    try:
        if style == 'bold':
            return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', size)
        elif style == 'regular':
            return ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', size)
        elif style == 'caladea_bold':
            return ImageFont.truetype('/usr/share/fonts/truetype/crosextra/Caladea-Bold.ttf', size)
    except Exception:
        pass
    # Fallback: try common Linux paths
    fallback_paths = {
        'bold': ['/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
                 '/usr/share/fonts/liberation/LiberationSans-Bold.ttf',
                 '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf'],
        'regular': ['/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf',
                    '/usr/share/fonts/liberation/LiberationSans-Regular.ttf',
                    '/usr/share/fonts/truetype/freefont/FreeSans.ttf'],
        'caladea_bold': ['/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf',
                         '/usr/share/fonts/liberation/LiberationSerif-Bold.ttf',
                         '/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf'],
    }
    for path in fallback_paths.get(style, []):
        if os.path.exists(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()

TOWN_CONFIG = {
    "cashiers": {
        "town_color": (120, 40, 35),
        "town_color_light": (160, 70, 60),
        "accent_color": (27, 120, 60),
        "accent_light": (72, 180, 100),
    },
    "highlands": {
        "town_color": (70, 100, 150),
        "town_color_light": (110, 140, 185),
        "accent_color": (27, 120, 60),
        "accent_light": (72, 180, 100),
    },
    "sylva": {
        "town_color": (35, 100, 50),
        "town_color_light": (65, 150, 80),
        "accent_color": (27, 120, 60),
        "accent_light": (72, 180, 100),
    },
    "franklin": {
        "town_color": (180, 80, 25),
        "town_color_light": (215, 120, 60),
        "accent_color": (35, 100, 50),
        "accent_light": (65, 150, 80),
    },
}

def make_image(town, title, date):
    town_key = town.lower()
    cfg = TOWN_CONFIG.get(town_key, TOWN_CONFIG["cashiers"])

    w, h = 2000, 1429
    canvas = Image.new('RGB', (w, h), (255, 255, 255))
    draw = ImageDraw.Draw(canvas)

    font_bold = get_font("bold", 130)
    font_regular = get_font("regular", 85)
    font_label = get_font("bold", 58)
    font_url = get_font("regular", 52)
    rt_font = get_font("caladea_bold", 115)
    nc_font = get_font("caladea_bold", 62)

    accent_color = cfg["accent_color"]
    accent_light = cfg["accent_light"]
    town_color = cfg["town_color"]
    town_color_light = cfg["town_color_light"]

    # Top label
    label = "WNC MARKET REPORT"
    lb = draw.textbbox((0, 0), label, font=font_label)
    draw.text(((w - (lb[2] - lb[0])) // 2, 75), label, fill=accent_light, font=font_label)
    draw.rectangle([(w // 2 - 220, 162), (w // 2 + 220, 170)], fill=accent_light)

    # Title lines
    lines = [title, "Market Update", date]
    y = 210
    for i, line in enumerate(lines):
        f = font_bold if i != 1 else font_regular
        bbox = draw.textbbox((0, 0), line, font=f)
        lw2 = bbox[2] - bbox[0]
        color = accent_color if i % 2 == 0 else accent_light
        extra = 30 if i == 1 else 0
        draw.text(((w - lw2) // 2, y + extra), line, fill=color, font=f)
        y += bbox[3] - bbox[1] + 25 + (30 if i == 1 else 0)

    # Town name
    town_upper = town.upper()
    rt_bbox = draw.textbbox((0, 0), town_upper, font=rt_font)
    rt_x = (w - (rt_bbox[2] - rt_bbox[0])) // 2
    rt_y = 1000
    draw.text((rt_x + 3, rt_y + 3), town_upper, fill=tuple(max(0, c - 50) for c in town_color), font=rt_font)
    draw.text((rt_x - 1, rt_y - 1), town_upper, fill=town_color_light, font=rt_font)
    draw.text((rt_x, rt_y), town_upper, fill=town_color, font=rt_font)

    nc_text = "· N C ·"
    nc_bbox = draw.textbbox((0, 0), nc_text, font=nc_font)
    nc_x = (w - (nc_bbox[2] - nc_bbox[0])) // 2
    nc_y = rt_y + 125
    draw.text((nc_x + 2, nc_y + 2), nc_text, fill=tuple(max(0, c - 50) for c in town_color), font=nc_font)
    draw.text((nc_x - 1, nc_y - 1), nc_text, fill=town_color_light, font=nc_font)
    draw.text((nc_x, nc_y), nc_text, fill=town_color, font=nc_font)

    # Bottom bar
    draw.rectangle([(80, h - 115), (w - 80, h - 105)], fill=accent_color)
    url_text = "wncmarketreport.com"
    ub = draw.textbbox((0, 0), url_text, font=font_url)
    draw.text(((w - (ub[2] - ub[0])) // 2, h - 88), url_text, fill=accent_color, font=font_url)

    buf = io.BytesIO()
    canvas.save(buf, format='PNG')
    buf.seek(0)
    return buf

@app.route('/generate', methods=['GET', 'POST'])
def generate():
    if request.method == 'POST':
        data = request.get_json() or {}
    else:
        data = request.args

    town = data.get('town', 'cashiers')
    title = data.get('title', 'Real Estate Market Update')
    date = data.get('date', '2026')

    img_buf = make_image(town, title, date)
    return send_file(img_buf, mimetype='image/png',
                     download_name=f'{town.lower()}-featured.png')

@app.route('/health')
def health():
    return {'status': 'ok'}

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)

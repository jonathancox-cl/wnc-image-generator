# WNC Image Generator

Generates featured images for WNC Market Report blog posts.

## Usage

POST /generate
{
  "town": "cashiers",
  "title": "Cashiers NC Real Estate",
  "date": "February 2026"
}

Returns a PNG image.

## Towns
- cashiers
- highlands
- sylva
- franklin
